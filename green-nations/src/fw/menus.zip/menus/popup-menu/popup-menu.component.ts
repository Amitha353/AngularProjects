import { Component, Input, OnInit } from '@angular/core';
import { MenuItem, MenuService } from 'src/fw/services/menu.service';
import { ScreenService } from 'src/fw/services/screen.service';

@Component({
  selector: 'fw-popup-menu',
  templateUrl: './popup-menu.component.html',
  styleUrls: ['./popup-menu.component.css']
})
export class PopupMenuComponent implements OnInit {

  @Input() menu: Array<MenuItem>;

  constructor(public menuService: MenuService, private screenService: ScreenService) { }

  ngOnInit(): void {
  }

  isLargeFit() {
    return this.screenService.isLarge();
  }
}
